﻿# Interview questions

**Question 1.** What is TextBlob? What is the aim of TextBlob?

**Question 2.** Lemmatize "Runners" word using textblob.

**Question 3.** What is the use of Wordnet?

**Question 4.** Explain Wordlist.

**Question 5.** Translate any sentence in your own language using TextBlob.