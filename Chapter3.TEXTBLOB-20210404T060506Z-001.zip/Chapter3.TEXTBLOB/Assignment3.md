﻿# Assignment 3

### Important Notes to follow for doing the assignmnets

1. Use Markdown to create your assignmnets. Use <a href="https://markdownmonster.west-wind.com/" target="_blank">Markdown_Monster</a> or <a href="https://typora.io/" target="_blank">Typora</a> to decorate your documents. 
2. There should be pictures attached to the needed documnets can be internet souce or self made.
3. Mention all the important formula and equations needed as per the topic
4. Upload all the assignments chapterwise/sectionwise.
5. Submit all your assignmnets before deadlines.
6. Write the answers below the specific questions.

**Question 1.** Write a python program using Textblob in which find out the parts-of-speech(pos) tagging from the following sentence.

"Susie works in a shoeshine shop. Where she shines she sits, and where she sits she shines"

**Question 2.** What is Wordlist? And, how it is different than tokenization?

**Question 3.** Write a python program using the textblob to find out the count of the common words from the following sentence.

"How much wood would a woodchuck chuck if a woodchuck could chuck wood?
He would chuck, he would, as much as he could, and chuck as much wood
As a woodchuck would if a woodchuck could chuck wood"
Find it out how many times 'wood' came in the sentence.

**Question 4.** Translate the following sentences in your own language using the textblob.

"Data is a new oil.", "A.I is the last invention", "She sells seashells by the seashore", "He threw three free throws".

**Question 5.** Create a spell checker program using the textblob library with using your own sentences.