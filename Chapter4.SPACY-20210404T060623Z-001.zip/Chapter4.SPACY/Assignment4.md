﻿# Assignment 4

### Important Notes to follow for doing the assignmnets

1. Use Markdown to create your assignmnets. Use <a href="https://markdownmonster.west-wind.com/" target="_blank">Markdown_Monster</a> or <a href="https://typora.io/" target="_blank">Typora</a> to decorate your documents. 
2. There should be pictures attached to the needed documnets can be internet souce or self made.
3. Mention all the important formula and equations needed as per the topic
4. Upload all the assignments chapterwise/sectionwise.
5. Submit all your assignmnets before deadlines.
6. Write the answers below the specific questions.

**Question 1.** Create a python program to find it out the Named entity recognition(NER) from the following sentence using spacy and visualizing those parts in sentence.

"I saw a kitten eating chicken in the kitchen"

**Question 2.** Find out the similar words from following list using spacy library.

["ship car truck motor-bike jeep hagskdshd"]

**Question 3.** Visualize sentences including parts of speech(pos) tagging and linguistic annotation in it by using spacy library.

**Question 4.** What is Word vector? And, how could you convert words into vector?

**Question 5.** Define Vocab, hashes and lexemes in your own word.